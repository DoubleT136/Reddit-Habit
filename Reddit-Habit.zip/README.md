# Reddit-Habit
__Author__: Tommy Tang

__Contact__: tommy9695@gmail.com

__Github__: https://github.com/DoubleT136

This is the chrome extension Reddit Habit. It tracks what subreddits you have visited on each day. This extension is open source.
